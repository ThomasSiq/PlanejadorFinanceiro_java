package gui.contentpanel;

import java.sql.SQLException;

import javax.swing.JPanel;

public class ContentPanel extends JPanel {

	/**
	 * Create the panel.
	 */
	public ContentPanel() {

	}
	
	public void attTabelas() throws SQLException {

	}

	public void updateTabela() throws SQLException {
		
	}

}
