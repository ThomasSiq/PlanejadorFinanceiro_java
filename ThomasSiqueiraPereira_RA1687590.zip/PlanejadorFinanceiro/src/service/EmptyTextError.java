package service;

public class EmptyTextError extends Exception {
	// TODO Auto-generated method stub
	public EmptyTextError(String mensagem) {
		super(mensagem);
	}
}