package teste;
import service.MainService;

public class Teste {
	public static void main(String[] args) {
		
	}
}
